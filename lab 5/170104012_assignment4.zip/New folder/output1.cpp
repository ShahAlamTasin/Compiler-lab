
float x1 = 3.125;;;

double f1(float a, int int x)
{if(x<x1)
double z;;
else z = 0.01;}}
else return z;
}

int main(void)
{{{{
int n1; double z;
n1=25; z=f1(n1);}