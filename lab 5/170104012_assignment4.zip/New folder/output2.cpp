1
2float x1 = 3.125;;;
3
4double f1(float a, int int x)
5{if(x<x1)
6double z;;
7else z = 0.01;}}
8else return z;
9}
10
11int main(void)
12{{{{
13int n1; double z;
14n1=25; z=f1(n1);}