1
2float id x1 = 3.125;;;
3
4double id f1(float id a, int int id x)
5{if(id x<id x1)
6double id z;;
7else id z = 0.01;}}
8else return id z;
9}
10
11int id main(void)
12{{{{
13int id n1; double id z;
14id n1=25; id z=id f1(id n1);}